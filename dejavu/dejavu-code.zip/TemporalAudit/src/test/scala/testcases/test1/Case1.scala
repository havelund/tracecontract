package testcases.test1

import testcases.TestCase

object Case1 extends TestCase {
  val test1 =
    Test(
      "forall (f) close(f) -> exists (m) true S open(f,m)",
      List(
        ("open", "tel" :: "w" :: Nil),
        ("close", "tel" :: Nil)
      ),
      List(
        List(
          "<0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0>",
          "TRUE",
          "<0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0>",
          "<0:0, 1:0, 2:0, 3:0>",
          "FALSE",
          "TRUE",
          "TRUE"
        ),
        List(
          "FALSE",
          "TRUE",
          "<0:0, 1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0>",
          "<0:0, 1:0, 2:0, 3:0>",
          "<0:0, 1:0, 2:0, 3:0>",
          "TRUE",
          "TRUE"
        )
      )
    )
}
