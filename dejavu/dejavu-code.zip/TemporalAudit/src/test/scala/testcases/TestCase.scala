package testcases

trait TestCase {
  type Event = (String, List[Any])
  type NowSpec = List[String]

  case class Test(spec: String, trace: List[Event], sat: List[NowSpec])
}
