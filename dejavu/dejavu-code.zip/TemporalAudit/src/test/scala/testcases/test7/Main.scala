
package testcases.test7

import net.sf.javabdd.{BDD, BDDFactory}
import java.io._
import java.io.{BufferedReader, FileReader, Reader}
import org.apache.commons.csv.{CSVFormat, CSVRecord}
import scala.collection.mutable.ListBuffer
import scala.collection.JavaConverters._

object MonitorUtil {
  type Binding = Map[String, Any]
  val emptyBinding: Binding = Map()
  val PRINT = true
  val BITS = 40
}

import MonitorUtil._

trait Pattern

case class V(name: String) extends Pattern

case class C(value: Any) extends Pattern

class State {
  type Event = (String, List[Any])

  var current: Event = null

  def update(name: String, args: List[Any]): Unit = {
    current = (name, args)
  }

  def holds(name: String, patterns: List[Pattern]): Option[Binding] = {
    val (cname, cargs) = current
    var binding: Binding = emptyBinding
    if (cname != name) None else {
      assert(patterns.size == cargs.size,
        s"patterns '${patterns.mkString(",")}' do not match args: '${cargs.mkString(",")}'")
      for ((pat, value) <- patterns.zip(cargs)) {
        pat match {
          case C(v) =>
            if (v != value) return None
          case V(x) =>
            if (binding.isDefinedAt(x)) {
              if (binding(x) != value) return None
            } else {
              binding += (x -> value)
            }
        }
      }
      Some(binding)
    }
  }

  override def toString: String = {
    s"""
       |#########################################################
       |##### ${current._1}(${current._2.mkString(",")})
       |#########################################################
    """.stripMargin('|')
  }
}

class Variable(offset: Int, nrOfBits: Int)(implicit B: BDDFactory) {
  var bits: Array[Int] = (for (x <- offset + nrOfBits - 1 to offset by -1) yield x).toArray
  var quantvar: BDD = B.buildCube(0, bits).support()
  var next: Int = -1
  var bdds: Map[Any, BDD] = Map()
  val MAXINT = Math.pow(2,nrOfBits)

  def nextInt(): Int = {
    next += 1
    assert(next < MAXINT,s"MAXINT $MAXINT reached")
    next
  }

  def getBddOf(v: Any): BDD = {
    bdds.get(v) match {
      case Some(bdd) => bdd
      case None =>
        val bdd = B.buildCube(nextInt(), bits)
        bdds += (v -> bdd)
        bdd
    }
  }
}

class BDDGenerator(variables: List[(String, Int)]) {
  implicit var B: BDDFactory = BDDFactory.init(10000, 10000)
  val True: BDD = B.one()
  val False: BDD = B.zero()
  var offset: Int = 0
  val totalNumberOfBits: Int = variables.map(_._2).sum
  var varMap: Map[String, Variable] = Map()

  B.setVarNum(totalNumberOfBits)

  for ((x, v) <- variables) {
    varMap += (x -> new Variable(offset, v))
    offset += v
  }

  def getBddOf(x: String, v: Any): BDD =
    varMap(x).getBddOf(v)
}

class Monitor {
  var bddGenerator: BDDGenerator = null
  val state: State = new State
  var formulae: List[Formula] = Nil
  var lineNr: Int = 0
  var DEBUG: Boolean = false
  val BITSPERVAR: Int = BITS
  var PRINT_LINENUMBER_EACH: Int = 1000

  def debug(str: String): Unit = {
    if (DEBUG) println(str)
  }

  def bddToString(bdd: BDD): String = {
    if (bdd.isZero)
      "False"
    else if (bdd.isOne)
      "True"
    else
      bdd.toString
  }

  def bddFromBinding(binding: Option[Binding]): BDD = {
    binding match {
      case None => bddGenerator.False
      case Some(b) =>
        var bdd: BDD = bddGenerator.True
        for ((x, v) <- b) {
          bdd = bdd.and(bddGenerator.getBddOf(x, v))
        }
        bdd
    }
  }

  def build(name: String)(patterns: Pattern*): BDD =
    bddFromBinding(state.holds(name, patterns.toList))

  def submit(name: String, args: List[Any]): Unit = {
    state.update(name, args)
    evaluate()
  }

  def submit(name: String, args: Any*): Unit = {
    submit(name, args.toList)
  }

  def submitTrace(events: List[(String, List[Any])]): Unit = {
    for ((event, args) <- events) {
      submit(event, args)
    }
  }

  def evaluate(): Unit = {
    debug(s"\n$state\n")
    for (formula <- formulae) {
      if (!formula.evaluate()) {
        println(s"\n*** Property ${formula.name} violated on event number $lineNr:\n")
        println(state)
      }
    }
  }

  implicit def liftBDD(bdd: BDD) = new {
    def print(): Unit = {
      bdd.printDot()
      // The following does not work:
      // val ps = new PrintStream(new File("bdd.dot"))
      // scala.Console.withOut(ps) {
      //   bdd.printDot()
      // }
      // ps.close()
    }
  }

  def time[R](block: => R): R = {
    val t1 = System.currentTimeMillis()
    val result = block
    val t2 = System.currentTimeMillis()
    val ms = (t2 - t1).toFloat
    val sec = ms / 1000
    println()
    println("Elapsed time: " + sec + "s")
    result
  }

  def verifyCSVFile(file: String) {
    val in: Reader = new BufferedReader(new FileReader(file))
    // DEFAULT.withHeader()
    val records: Iterable[CSVRecord] = CSVFormat.DEFAULT.parse(in).asScala
    lineNr = 0
    time {
      for (record <- records) {
        lineNr += 1
        if (PRINT) {
          if (lineNr % PRINT_LINENUMBER_EACH == 0) {
            if (lineNr >= 1000000)
              println(lineNr.toDouble / 1000000 + " M")
            else
              println(lineNr.toDouble / 1000 + " K")
          }
        }
        val name = record.get(0)
        var args = new ListBuffer[Any]()
        for (i <- 1 until record.size()) {
          args += record.get(i)
        }
        submit(name, args.toList)
      }
    }
    in.close()
  }

  abstract class Formula {
    var name: String = this.getClass.getSimpleName.split("_")(1)
    var pre: Array[BDD] = null
    var now: Array[BDD] = null
    var tmp: Array[BDD] = null
    var txt: Array[String] = null

    var True: BDD = null
    var False: BDD = null

    def declareVariables(variables: String*): List[BDD] = {
      val variableList = variables.toList
      val varsAndBitsPerVar = variableList.map {
        case v => (v, BITSPERVAR)
      }
      bddGenerator = new BDDGenerator(varsAndBitsPerVar)
      True = bddGenerator.True
      False = bddGenerator.False
      variableList.map(bddGenerator.varMap(_).quantvar)
    }

    def evaluate(): Boolean

    override def toString: String = {
      var result: String = ""
      result += s"===============\n"
      result += s"Property $name:\n"
      result += s"===============\n"
      for (i <- 0 to now.size - 1) {
        result += s"[$i] ${txt(i)}\n\n"
        result += s"pre: ${bddToString(pre(i))}\n"
        result += s"now: ${bddToString(now(i))}\n"
        result += s"-------------\n"
      }
      result
    }

    def debugMonitorState(): Unit = {
      if (DEBUG) {
        println("================")
        println(s"Property: $name")
        println("================")
        println()
        if (now(0).isZero) {
          println("*** FALSE ***")
          println()
        }
        for (i <- now.size - 1 to 0 by -1) {
          println(s"----- $i -----")
          println(txt(i))
          if (now(i).isOne) println("TRUE") else if (now(i).isZero) println("FALSE") else {
            println(s"now:")
            println(now(i))
            now(i).print()
          }
        }
      }
    }
  }

}

class PropertyMonitor extends Monitor {

  /*
    property p: forall x . (enter(x) -> !@ P enter(x)) & (exit(x) -> !@ P exit(x)) & (exit(x) -> @ P enter(x)) & (forall y . (exit(y) & P (enter(y) & @ P enter(x))) -> @ P exit(x))
  */

  class Formula_p extends Formula {

    val var_x :: var_y :: Nil = declareVariables("x", "y")

    override def evaluate(): Boolean = {
      now(5) = build("enter")(V("x"))
      now(9) = build("enter")(V("x"))
      now(8) = now(9).or(pre(8))
      now(7) = pre(8)
      now(6) = now(7).not()
      now(4) = now(5).not().or(now(6))
      now(11) = build("exit")(V("x"))
      now(15) = build("exit")(V("x"))
      now(14) = now(15).or(pre(14))
      now(13) = pre(14)
      now(12) = now(13).not()
      now(10) = now(11).not().or(now(12))
      now(3) = now(4).and(now(10))
      now(17) = build("exit")(V("x"))
      now(20) = build("enter")(V("x"))
      now(19) = now(20).or(pre(19))
      now(18) = pre(19)
      now(16) = now(17).not().or(now(18))
      now(2) = now(3).and(now(16))
      now(24) = build("exit")(V("y"))
      now(27) = build("enter")(V("y"))
      now(30) = build("enter")(V("x"))
      now(29) = now(30).or(pre(29))
      now(28) = pre(29)
      now(26) = now(27).and(now(28))
      now(25) = now(26).or(pre(25))
      now(23) = now(24).and(now(25))
      now(33) = build("exit")(V("x"))
      now(32) = now(33).or(pre(32))
      now(31) = pre(32)
      now(22) = now(23).not().or(now(31))
      now(21) = now(22).forAll(var_y)
      now(1) = now(2).and(now(21))
      now(0) = now(1).forAll(var_x)

      debugMonitorState()

      tmp = now
      now = pre
      pre = tmp
      !tmp(0).isZero
    }

    pre = Array.fill(34)(False)
    now = Array.fill(34)(False)

    txt = Array(
      "forall x . (enter(x) -> !@ P enter(x)) & (exit(x) -> !@ P exit(x)) & (exit(x) -> @ P enter(x)) & (forall y . (exit(y) & P (enter(y) & @ P enter(x))) -> @ P exit(x))",
      "(enter(x) -> !@ P enter(x)) & (exit(x) -> !@ P exit(x)) & (exit(x) -> @ P enter(x)) & (forall y . (exit(y) & P (enter(y) & @ P enter(x))) -> @ P exit(x))",
      "(enter(x) -> !@ P enter(x)) & (exit(x) -> !@ P exit(x)) & (exit(x) -> @ P enter(x))",
      "(enter(x) -> !@ P enter(x)) & (exit(x) -> !@ P exit(x))",
      "enter(x) -> !@ P enter(x)",
      "enter(x)",
      "!@ P enter(x)",
      "@ P enter(x)",
      "P enter(x)",
      "enter(x)",
      "exit(x) -> !@ P exit(x)",
      "exit(x)",
      "!@ P exit(x)",
      "@ P exit(x)",
      "P exit(x)",
      "exit(x)",
      "exit(x) -> @ P enter(x)",
      "exit(x)",
      "@ P enter(x)",
      "P enter(x)",
      "enter(x)",
      "forall y . (exit(y) & P (enter(y) & @ P enter(x))) -> @ P exit(x)",
      "(exit(y) & P (enter(y) & @ P enter(x))) -> @ P exit(x)",
      "exit(y) & P (enter(y) & @ P enter(x))",
      "exit(y)",
      "P (enter(y) & @ P enter(x))",
      "enter(y) & @ P enter(x)",
      "enter(y)",
      "@ P enter(x)",
      "P enter(x)",
      "enter(x)",
      "@ P exit(x)",
      "P exit(x)",
      "exit(x)"
    )

    debugMonitorState()
  }

  formulae ++= List(new Formula_p)

}

object Main {
  def main(args: Array[String]): Unit = {
    val m = new PropertyMonitor
    val file = "src/test/scala/testcases/test7/log1.csv"
    m.DEBUG = false
    m.verifyCSVFile(file)
  }
}