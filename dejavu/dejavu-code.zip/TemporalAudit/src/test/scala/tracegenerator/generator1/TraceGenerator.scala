package tracegenerator.generator1

import java.io._

trait Generator {
  var counter: Int = 0
  type Evr = (Int, String, List[Any])
  val fileMonPoly = "/Users/khavelun/Desktop/log-monpoly.txt"
  val fileQTL = "/Users/khavelun/Desktop/log-qtl.txt"
  val pwMonPoly = new PrintWriter(new File(fileMonPoly))
  val pwQTL = new PrintWriter(new File(fileQTL))

  def repeat(nr: Int)(code: => Unit): Unit = {
    for (i <- 1 to nr) {
      counter += 1
      code
    }
  }

  def iterate(limit1: Int, limit2: Int, step: Int = 1)(event: String, arguments: Any*): Unit = {
    println(s"---from $limit1 to $limit2 step $step : $event(${arguments.mkString(",")}) ------------------------")
    val args = arguments.toList
    for (i <- limit1 to limit2 by step) {
      counter += 1
      val evr: Evr = (counter, event, i :: args)
      emitEvr(evr)
    }
  }

  def emitEvr(evr: Evr): Unit = {
    val formattedMonPoly = formatMonPoly(evr)
    val formattedQTL = formatQTL(evr)
    println(formattedQTL)
    //println(formattedMonPoly)
    pwQTL.write(formattedQTL + "\n")
    pwMonPoly.write(formattedMonPoly + "\n")
  }

  def emit(event: String, args: Any*): Unit = {
    val evr = (counter, event, args.toList)
     emitEvr(evr)
  }

  def formatQTL(event: Evr): String = {
    val (counter, name, args) = event
    s"$name,${args.mkString(",")}"
  }

  def formatMonPoly(event: Evr): String = {
    val (counter, name, args) = event
    f"@$counter%07d $name (${args.mkString(",")})"
  }

  //  @000001 open (aaa)
  //  @000002 open (aah)

  def up(limit1: Int, limit2: Int)(event: String, arguments: Any*): Unit = {
    iterate(limit1, limit2)(event: String, arguments: _*)
  }

  def down(limit1: Int, limit2: Int)(event: String, arguments: Any*): Unit = {
    iterate(limit1, limit2, -1)(event: String, arguments: _*)
  }

  def end(): Unit = {
    println(s"$counter events generated")
    pwMonPoly.close()
    pwQTL.close()
  }

  def run()
}


class Generator5 extends Generator {
  /*

    prop secure :
      forall user . forall file .
         access(user,file) ->
           [login(user),logout(user))
             &
            [open(file),close(file))
   */

  val login = "login"
  val logout = "logout"
  val open = "open"
  val close = "close"
  val access = "access"

  def run(): Unit = {
    // val MAX = 5000; val MID = 4800 // 11,006 events generated
    // val MAX = 50000; val MID = 48000 // 110,006 events generated
    val MAX = 500000; val MID = 480000 // 1,100,006 events generated

    up(1, MAX)(login)
    up(1, MAX)(open)
    repeat(1) {
      down(MAX,MID)(access,1)
      down(MAX, MID)(close)
      up(MID, MAX)(open)
    }
    down(MAX, MID)(logout)
    down(MAX, MID)(close)
    emit(access,MAX,1)
    end()
  }
}

class Generator6 extends Generator {
  /*
    prop p : forall f . close(f) -> exists m . @ [open(f,m),close(f))
   */

  val open = "open"
  val close = "close"
  val read = "read"
  val write = "write"

  def run(): Unit = {
    // val MAX = 8000; val MID = 7000 // 11,004 events generated
    // val MAX = 80000; val MID = 70000 // 110,004 events generated
    val MAX = 800000; val MID = 700000 // 1,100,004 events generated

    up(1, MAX)(open,read)
    repeat(1) {
      down(MAX,MID)(close)
      up(MID, MAX)(open,write)
    }
    down(MAX, MID)(close)
    emit(close,MAX)
    end()
  }
}

class Generator7 extends Generator {
  /*
     prop p1 : forall x . enter(x) -> ! @ P enter(x)
     prop p2 : forall x . exit(x) -> ! @ P exit(x)
     prop p3 : forall x . exit(x) -> @ P enter(x)
     prop p4 : forall x . forall y . (P (enter(y) & @ P enter(x))) & exit(y) -> @ P exit(x)
   */

  val enter = "enter"
  val exit = "exit"

  def run(): Unit = {
    // val MAX = 5000; val MID = 50 // 5,050 events generated
    // val MAX = 10000; val MID = 100 // 10,100 events generated
    // val MAX = 100000; val MID = 1000 // 101,000 events generated
    val MAX = 1000000; val MID = 10000 // 1,010,000 events generated
    up(1, MAX)(enter)
    up(1, MID)(exit)
    emit(exit,MAX)
    end()
  }
}

object Main {
  def main(args: Array[String]): Unit = {
    val generator = new Generator7
    generator.run()
  }
}
