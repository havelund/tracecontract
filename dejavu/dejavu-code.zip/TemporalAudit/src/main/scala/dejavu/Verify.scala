package dejavu

import scala.io.Source
import java.io._

object Verify {
  def time[R](text: String)(block: => R): R = {
    val t1 = System.currentTimeMillis()
    val result = block
    val t2 = System.currentTimeMillis()
    val ms = (t2 - t1).toFloat
    val sec = ms / 1000
    println(s"\n--- Elapsed $text time: " + sec + "s" + "\n")
    result
  }

  def exec(cmd: String*) {
    // println(s"\n--- [${cmd.mkString(" ")}] ---\n")
    val cmdArray = cmd.toArray
    val process =
      if (cmdArray.length == 1) Runtime.getRuntime exec cmd(0) else Runtime.getRuntime exec cmdArray
    val input = process.getInputStream
    val error = process.getErrorStream
    val inputSource = Source fromInputStream input
    val errorSource = Source fromInputStream error
    for (line <- inputSource.getLines()) {
      if (!line.startsWith("Could not load BDD") && !line.startsWith("Resizing node table")) {
        println(line)
      }
    }
    for (line <- errorSource.getLines()) {
      if (!line.contains("warning") && !line.startsWith("Garbage collection")) {
        println(line)
      }
    }
  }

  def compileAndExecute(args: String): Unit = {
    time("monitor compilation") {
      println("Compiling generated monitor ...")
      exec("scalac -cp .:lib/commons-csv-1.1.jar:lib/javabdd-1.0b2.jar TraceMonitor.scala")
    }
    time("trace analysis") {
      println("Analyzing trace ...")
      exec(s"scala -J-Xmx16g -cp .:lib/commons-csv-1.1.jar:lib/javabdd-1.0b2.jar TraceMonitor $args")
    }
    exec("sh", "-c", "rm *.class") // multi-argument call needed due to occurrence of *
  }

  def main(arguments: Array[String]) {
    val args = arguments.toList
    if (args.length < 1 || args.length > 4) {
      println("*** wrong number of arguments, call with: <specfile> [ <logfile> [ <bitspervar> [debug] ] ]")
      return
    }
    if (args.length > 2 && !args(2).matches("""\d+""")) {
      println(s"*** third argument must be an integer, and not ${args(2)}")
      return
    }
    if (args.length == 4 && args(3) != "debug") {
      println(s"*** fourth argument must be: debug, and not ${args(3)}")
      return
    }
    time("total") {
      time("monitor synthesis") {
        val p = new Parser
        val file = arguments(0)
        val spec = p.parseFile(file)
        spec.translate()
      }
      if (args.length > 1) compileAndExecute(args.tail.mkString(" "))
    }
  }
}
