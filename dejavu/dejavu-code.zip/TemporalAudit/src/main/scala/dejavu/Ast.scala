package dejavu

import java.io._

import scala.io.Source

object AstUtil {
  val DEBUG_BRACKETS = false
  val DEBUG_AST = true

  def quote(s: Any) = "\"" + s + "\""

  def iquote(s: Any) = "\\\"" + s + "\\\""

  def bracket(s: Any): String = if (DEBUG_BRACKETS) s"[$s]" else s.toString

  // --- File writing begin: ---

  var pw: PrintWriter = null

  def openFile(name: String): Unit = {
    pw = new PrintWriter(new File(name))
  }

  def closeFile(): Unit = {
    pw.close()
  }

  def write(x: Any) = {
    // Predef.print(x)
    pw.write(x.toString)
  }

  def writeln() = {
    // Predef.println()
    pw.write("\n")
  }

  def writeln(x: Any) = {
    // Predef.println(x)
    pw.write(x + "\n")
  }

  // --- File writing end ---
}

import AstUtil._

case class Spec(properties: List[Property]) {
  def translate(): Unit = {
    val monitorFileIn = "src/main/scala/dejavu/Monitor.scala"
    val monitorFileOut = "TraceMonitor.scala"
    openFile(monitorFileOut)
    // val monitor = Source.fromFile(monitorFileIn).getLines.drop(1).mkString("\n") // drop package name
    val monitor = MonitorCode.monitorCode
    writeln(monitor)
    writeln()
    writeln("class PropertyMonitor extends Monitor {")
    for (property <- properties) {
      val name = property.name
      val variables = property.ltl.getVariables
      writeln(
        s"""
           |  /*
           |    property $name: ${property.ltl}
           |  */
           |
           |  class Formula_$name extends Formula {
          """
          .stripMargin)

      val lhs = variables.map(x => s"var_$x").mkString(" :: ") + " :: Nil"
      val rhs = variables.map(quote(_)).mkString(", ")
      writeln(s"    val $lhs = declareVariables($rhs)")
      writeln()

      writeln("    override def evaluate(): Boolean = {")
      LTL.reset()
      property.ltl.translate()
      val size = LTL.next
      val subFormulas = LTL.subExpressions.map(e => quote(e.toString)).mkString(",\n      ")
      writeln(
        s"""
           |      debugMonitorState()
           |
           |      tmp = now
           |      now = pre
           |      pre = tmp
           |      !tmp(0).isZero
           |    }
           |
           |    pre = Array.fill($size)(False)
           |    now = Array.fill($size)(False)
           |
           |    txt = Array(
           |      $subFormulas
           |    )
           |
           |    debugMonitorState()
           |  }
           |
           |  formulae ++= List(new Formula_$name)
        """.stripMargin)
    }
    writeln("}")
    writeln(
      """
        |object TraceMonitor {
        |  def main(args: Array[String]): Unit = {
        |    if (1 <= args.length && args.length <= 3) {
        |      if (args.length > 1) MonitorUtil.BITS = args(1).toInt
        |      val m = new PropertyMonitor
        |      val file = args(0)
        |      if (args.length == 3 && args(2) == "debug") m.DEBUG = true
        |      try {
        |        m.verifyCSVFile(file)
        |      } catch {
        |        case e: Throwable => println(s"\n*** $e\n")
        |      }
        |    } else {
        |      println("*** wrong number of arguments: provide file name of CSV log file")
        |      println("<logfile> [debug]")
        |    }
        |  }
        |}
      """.stripMargin)
    closeFile()
    if (DEBUG_AST) printDot()
  }

  override def toString: String =
    properties.mkString("\n")

  def printDot() {
    val pw = new PrintWriter(new File("ast.dot"))
    for (p <- properties) {
      pw.write("digraph G {\n")
      pw.write(p.ltl.toDot)
      pw.write("}\n")
    }
    pw.close
  }
}


case class Property(name: String, ltl: LTL) {
  override def toString: String =
    s"$name : $ltl"
}

trait LTL {
  var index: Int = 0

  def assign(index: Int)(rhs: String): Unit = {
    writeln(s"      now($index) = $rhs")
  }

  def getVariables: List[String] = Nil

  def translate(): Int = {
    index = LTL.getIndex()
    LTL.subExpressions ++= List(this)
    index
  }

  def toDot = s"  $index [shape=box, label=${quote(index + " : " + toString)}]\n"
}

object LTL {
  var next: Int = 0

  var subExpressions: List[LTL] = Nil

  def getIndex(): Int = {
    val index = next
    next += 1
    index
  }

  def reset(): Unit = {
    next = 0
    subExpressions = Nil
  }
}

case object True extends LTL {
  override def translate(): Int = {
    super.translate()
    assign(index)("True")
    index
  }

  override def toString: String = "true"
}

case object False extends LTL {
  override def translate(): Int = {
    super.translate()
    assign(index)(s"False")
    index
  }

  override def toString: String = "false"
}

case class Pred(name: String, values: List[ConstOrVar]) extends LTL {
  override def translate(): Int = {
    super.translate()
    val predName = quote(name)
    val patterns = values.map(_.toStringForSynthesis).mkString(",")
    assign(index)(s"build($predName)($patterns)")
    index
  }

  override def toString: String = {
    val patterns =
      if (values.isEmpty) "" else "(" + values.map(_.toString).mkString(",") + ")"
    s"$name$patterns"
  }
}

case class Paren(ltl: LTL) extends LTL {
  override def getVariables: List[String] = ltl.getVariables

  override def translate(): Int = {
    index = ltl.translate()
    index
  }

  override def toString: String = s"($ltl)"

  override def toDot: String = ltl.toDot
}

case class Not(ltl: LTL) extends LTL {
  override def getVariables: List[String] = ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"now($index1).not()")
    index
  }

  override def toString: String = s"!$ltl"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class Or(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[String] = ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index1).or(now($index2))")
    index
  }

  override def toString: String = s"${bracket(ltl1)} | ${bracket(ltl2)}"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class And(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[String] = ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index1).and(now($index2))")
    index
  }

  override def toString: String = s"${bracket(ltl1)} & ${bracket(ltl2)}"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class Implies(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[String] = ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index1).not().or(now($index2))")
    index
  }

  override def toString: String = s"${bracket(ltl1)} -> ${bracket(ltl2)}"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class Since(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[String] =
    ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index2).or(now($index1).and(pre($index)))")
    index
  }

  override def toString: String = s"${bracket(ltl1)} S ${bracket(ltl2)}"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class Previous(ltl: LTL) extends LTL {
  override def getVariables: List[String] = ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"pre($index1)")
    index
  }

  override def toString: String = s"@ $ltl"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class Sometime(ltl: LTL) extends LTL {
  override def getVariables: List[String] = ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"now($index1).or(pre($index))")
    index
  }

  override def toString: String = s"P $ltl"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class History(ltl: LTL) extends LTL {
  override def getVariables: List[String] = ltl.getVariables

  val rewrite: LTL = Not(Sometime(Not(ltl)))

  override def translate(): Int = {
    rewrite.translate()
    index = rewrite.index // Not sure this works
    index
  }

  override def toString: String = s"H $ltl"

  override def toDot: String = {
    rewrite.toDot
  }
}

case class Interval(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[String] =
    ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index1).or(now($index2).not().and(pre($index)))")
    index
  }

  override def toString: String = s"[$ltl1,$ltl2)"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class Exists(name: String, ltl: LTL) extends LTL {
  override def getVariables: List[String] = List(name) ++ ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"now($index1).exist(var_$name)")
    index
  }

  override def toString: String = s"exists $name . ${bracket(ltl)}"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class Forall(name: String, ltl: LTL) extends LTL {
  override def getVariables: List[String] = List(name) ++ ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"now($index1).forAll(var_$name)")
    index
  }

  override def toString: String = s"forall $name . ${bracket(ltl)}"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

trait ConstOrVar {
  def toStringForSynthesis: String
}

case class CPat(value: Any) extends ConstOrVar {
  def toStringForSynthesis: String = {
    //val v = if (value.isInstanceOf[String]) quote(value) else value.toString
    s"C($value)"
  }

  override def toString: String = value.toString
}

case class VPat(variable: String) extends ConstOrVar {
  def toStringForSynthesis: String = {
    s"V(${quote(variable)})"
  }

  override def toString: String = variable
}