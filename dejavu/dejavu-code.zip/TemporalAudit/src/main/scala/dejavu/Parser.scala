package dejavu

import scala.util.parsing.combinator._
import java.io._


class Parser extends JavaTokenParsers {

  protected override val whiteSpace = """(\s|/\*(.|\n|\r)*?\*/|//.*\n)+""".r

  def reserved: Parser[String] =
    "prop\\b".r |
      "H\\b".r |
      "P\\b".r |
      "S\\b".r |
      "forall\\b".r |
      "exists\\b".r |
      "true\\b".r |
      "false\\b".r

  val name: Parser[String] = not(reserved) ~> ident

  def spec: Parser[Spec] = rep(property) ^^ {
    case properties => Spec(properties)
  }

  def property: Parser[Property] =
    "prop" ~ name ~ ":" ~ ltl ^^ {
      case _ ~ id ~ _ ~ ltl =>
        Property(id, ltl)
    }

  def ltl: Parser[LTL] =
    ltl1 ~ rep("->" ~ ltl1) ^^ {
      case ltl ~ ltls => mkBinary(ltl, ltls)
    }

  def ltl1: Parser[LTL] =
    ltl2 ~ rep("|" ~ ltl2) ^^ {
      case ltl ~ ltls => mkBinary(ltl, ltls)
    }

  def ltl2: Parser[LTL] =
    ltl3 ~ rep("&" ~ ltl3) ^^ {
      case ltl ~ ltls => mkBinary(ltl, ltls)
    }

  def ltl3: Parser[LTL] =
    ltlLeaf ~ rep("S" ~ ltlLeaf) ^^ {
      case ltl ~ ltls => mkBinary(ltl, ltls)
    }

  def ltlLeaf: Parser[LTL] =
    "true" ^^ {
      case _ => True
    } |
      "false" ^^ {
        case _ => False
      } |
      name ~ opt("(" ~ repsep(constOrVar,",") ~ ")") ^^ {
        case id ~ optConstOrVars =>
          val constOrVars = optConstOrVars match {
            case None => Nil
            case Some(_ ~ as ~ _) => as
          }
          Pred(id, constOrVars)
      } |
      "!" ~ ltlLeaf ^^ {
        case _ ~ ltl => Not(ltl)
      } |
      "@" ~ ltlLeaf ^^ {
        case _ ~ ltl => Previous(ltl)
      } |
      "P" ~ ltl ^^ {
        case _ ~ ltl => Sometime(ltl)
      } |
      "H" ~ ltl ^^ {
        case _ ~ ltl => History(ltl)
      } |
      "[" ~ ltl ~ "," ~ ltl ~ ")" ^^ {
        case _ ~ ltl1 ~ _ ~ ltl2 ~ _ => Interval(ltl1,ltl2)
      } |
      "exists" ~  name ~ "." ~ ltl ^^ {
        case _ ~ id ~ _ ~ ltl => Exists(id, ltl)
      } |
      "forall" ~ name ~ "." ~ ltl ^^ {
        case _ ~ id ~ _ ~ ltl => Forall(id, ltl)
      } |
      "(" ~ ltl ~ ")" ^^ {
        case _ ~ ltl ~ _ => Paren(ltl)
      }

  def constOrVar: Parser[ConstOrVar] =
    name ^^ {
      case id => VPat(id)
    } |
      (stringLiteral | wholeNumber) ^^ {
        case v => CPat(v)
      }

  // --------------- AUXILIARY -----------------

  def mkBinary(t: LTL, ts: List[String ~ LTL]): LTL =
    ts match {
      case Nil => t
      case (op ~ t_) :: ts_ =>
        val binary =
          op match {
            case "->" => Implies(t, t_)
            case "|" => Or(t, t_)
            case "&" => And(t, t_)
            case "S" => Since(t, t_)
          }
        mkBinary(binary, ts_)
    }

  // --------------- PARSING -------------------

  // generic:

  def readerFromFile(file: String): java.io.Reader =
    new FileReader(file)

  def readerFromString(str: String): java.io.Reader =
    new StringReader(str)

  // parsing any NT:

  def parseReader(reader: java.io.Reader): Spec =
    parseAll(spec, reader) match {
      case Success(e, _) =>
        return e
      case fail@NoSuccess(_, _) =>
        println(fail)
        assert(false).asInstanceOf[Spec]
    }

  def parseFile(file: String): Spec =
    parseReader(readerFromFile(file))

  def parseString(str: String): Spec =
    parseReader(readerFromString(str))
}


