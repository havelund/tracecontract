package examples.example1

import dejavu.{BDDGenerator, Monitor, V}

// ---- begin monitor: ---

class PropertyMonitor extends Monitor {

  /*
    property p: forall (m) send(m) -> forall (f) H !open(f)
  */

  class Formula_p extends Formula {

    val var_m :: var_f :: Nil = declareVariables("m", "f")

    override def evaluate(): Boolean = {
      now(2) = build("send")(V("m"))
      now(8) = build("open")(V("f"))
      now(7) = now(8).not()
      now(6) = now(7).not()
      now(5) = now(6).or(pre(5))
      now(4) = now(5).not()
      now(3) = now(4).forAll(var_f)
      now(1) = now(2).not().or(now(3))
      now(0) = now(1).forAll(var_m)

      debugMonitorState()

      tmp = now
      now = pre
      pre = tmp
      !tmp(0).isZero
    }

    pre = Array.fill(9)(False)
    now = Array.fill(9)(False)

    txt = Array(
      "forall (m) send(m) -> forall (f) H !open(f)",
      "send(m) -> forall (f) H !open(f)",
      "send(m)",
      "forall (f) H !open(f)",
      "!P !!open(f)",
      "P !!open(f)",
      "!!open(f)",
      "!open(f)",
      "open(f)"
    )

    debugMonitorState()
  }

  formulae ++= List(new Formula_p)

}

// --- end monitor: ---


object Main {
  def main(args: Array[String]): Unit = {
    val m = new PropertyMonitor
    m.DEBUG = true

    m.submit("open", "f42")
    m.submit("close", "f42")
    m.submit("send", 254)
  }
}