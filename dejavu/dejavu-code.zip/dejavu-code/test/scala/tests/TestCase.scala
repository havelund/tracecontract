package tests

import scala.io.Source
import dejavu.Settings

class TestCase {
  val PATH_TO_TESTS = Settings.PROJECT_DIR + "/src/test/scala/tests"

  def readResult(): List[Int] = {
    Source.fromFile("dejavu-results").getLines.toList.map(_.toInt)
  }

  def checkViolations(lines : Int*): Unit = {
    val expect = lines.toList
    val result = readResult()
    assert(expect == result,
      s"""
         |${expect.mkString(",")}
         |=/+
         |${result.mkString(",")}
       """.stripMargin)
  }
}
