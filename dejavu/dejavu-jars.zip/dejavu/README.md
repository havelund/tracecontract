
        _____       _    __      __    
       |  __ \     (_)   \ \    / /    
       | |  | | ___ _  __ \ \  / /   _ 
       | |  | |/ _ \ |/ _` \ \/ / | | |
       | |__| |  __/ | (_| |\  /| |_| |
       |_____/ \___| |\__,_| \/  \__,_|
                  _/ |                 
                 |__/                  
 

## Folder Contents

This folder contains beyond this README.md file (in mark down format: https://en.wikipedia.org/wiki/Markdown) the following three jar files:

* dejavu.jar : the dejavu system
* commons-csv-1.1.jar : parsing of files in CSV format (https://commons.apache.org/proper/commons-csv/)
* javabdd-1.0b2.jar : the JavaBDD package (http://javabdd.sourceforge.net)

as well as:

* dejavu : script to run the system

## Installation of DejaVu

1. Install the Scala programming language if not already installed (https://www.scala-lang.org/download)
2. Place the dejavu folder in some directory **DIR** (standing for the total path to this directory).
3. Edit the dejavu script in the dejavu folder, re-defining DEJAVU to denote the location on the dejavu folder:
       
         DEJAVU=DIR/dejavu
4. Make the file executable:

        chmod +x dejavu
     
5. Preferably define an alias in your shell profile to the dejavu script so it can be called from anywhere:

        alias dejavu=DIR/dejavu/dejavu
        
## Running DejaVu

The script is applied as follows:

    dejavu <specFile> <logFile> [<bitsPerVariable>]
        
**The specfile** (specFile) should follow the following grammar:

    <spec> ::= <prop> ... <prop>
    <prop> ::= 'prop' <id> ':' <form> 
    <form> ::= 'true' | 'false' 
     | <id> [ '(' <param> ',' ... ',' <param> `)' ]
     | <form> <binop> <form> 
     | '[' <form> ',' <form> ')'
     | <unop>  <form>
     | ('exists' | 'forall') <id> '.' <form>
     | '(' <form> ')'
    <binop> ::= '->' | '|' | '&' | 'S'
    <unop>  ::= '!' |  '@' | 'P' | 'H'
    <param> ::= <id> | <string> | <integer>

With the following meaning:

    id : p        : property with name id
    exists x . p  : there exists an x such that p is true
    forall x . p  : for all x p is true
    id(p1,...,pn) : event where pi can be a constant or variable
    p -> q        : p implies q
    p | q         : p or q
    p & q         : p and q
    [p,q)         : interval notation equivalent to !q S p
    p S q         : p since q 
    @ q           : in previous state q is true
    P q           : in some previous state q is true
    H q           : in all previous states q is true

**The log file** (logFile) should be in comma separated value format (CSV):
http://edoceo.com/utilitas/csv-file-format. For example, a file of
the form:

    login,John,10
    login,Ann,42

with **no leading spaces** would mean two events:

    login(John,10)
    login(Ann,42)

**The bits per variable** (bitsPerVariable) indicates how many bits are assigned to each variable in the BDDs. This parameter is optional with the default value being 20. If the number is too low an error message will be issued during analysis as explained below. A too high number can have impact on the efficiency of the algorithm. Note that the number of values representable by N bits is 2^N, so one in general does not need very large numbers.  

## Results from DejaVu
    
**Property violations** 
The tool will indicate a violation of a property by printing
what event number it concerns and what event. For example:

    *** Property secure violated on event number 701:

    #########################################################
    #### access(John,passwordfile)
    #########################################################  
    
indicates that event number 701 violates the property 'security', and that event is a line in the CSV file having the format:

    access,John,passwordfile   

**Not enough bits per variable**
If not enough bits have been allocated for a variable to hold the number of values generated for that variable, an assertion violation like the following is printed:

    *** java.lang.AssertionError: assertion failed: MAXINT 1024.0 reached

Hence one can experiment with BDD sizes. A too small number will be flagged during trace analysis.

**Other errors** Syntax errors in the specifications. 

**Timing results**
The system will print the following timings:

* the time spent on parsing spec and synthesizing monitor (Scala program)
* the time spent on compiling the synthesized monitor
* the time spent on verifying trace with compiled monitor

**Generated files for FYI**
The system will generate a file named TraceMonitor.scala containing the synthesized monitor, as well as a ast.dot file
showing the structure of the formula (used for generating BDD updating code). This can be viewed with GraphViz (http://www.graphviz.org). These two files help illustrate how the algorithm works.
    
## Enjoy!