package dejavu

object Settings {
  // It would be better if the following was computed automatically
  var PROJECT_DIR = “…”
}
