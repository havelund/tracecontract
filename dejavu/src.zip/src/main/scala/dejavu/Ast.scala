package dejavu

import java.io._

import scala.io.Source

object AstUtil {
  val DEBUG_BRACKETS = false
  val DEBUG_AST = true

  def quote(s: Any) = "\"" + s + "\""

  def iquote(s: Any) = "\\\"" + s + "\\\""

  def bracket(s: Any): String = if (DEBUG_BRACKETS) s"[$s]" else s.toString

  // --- File writing begin: ---

  var pw: PrintWriter = null

  def openFile(name: String): Unit = {
    pw = new PrintWriter(new File(name))
  }

  def closeFile(): Unit = {
    pw.close()
  }

  def write(x: Any) = {
    // Predef.print(x)
    pw.write(x.toString)
  }

  def writeln() = {
    // Predef.println()
    pw.write("\n")
  }

  def writeln(x: Any) = {
    // Predef.println(x)
    pw.write(x + "\n")
  }

  // --- File writing end ---

  /**
    * This method copies the code in Monitor.scala to Monitor.txt (except for the initial package
    * declaration). Monitor.txt becomes part of the generated monitoring code for a set of
    * properties. This approach is necessary since Monitor.scala will not be available in
    * the generated jar file. The method only has  a side effect in development mode where
    * Monitor.scala is available, and is called each time the system (Verify.main) is run.
    */

  def refreshMonitorTextIfDevelopment(): Unit = {
    val dejavuDir = "/Users/khavelun/Desktop/development/ideaworkspace/dejavu/src/main/scala/dejavu/"
    val monitorFreshFileIn = dejavuDir + "Monitor.scala"
    if (new java.io.File(monitorFreshFileIn).exists) { // true in development environment
      val monitorFreshText = Source.fromFile(monitorFreshFileIn).getLines.drop(1).mkString("\n") // drop package name
    val monitorFreshFileOut = dejavuDir + "Monitor.txt"
      openFile(monitorFreshFileOut)
      writeln(monitorFreshText)
      closeFile()
    }
  }
}

import AstUtil._

case class Spec(properties: List[Property]) {
  def translate(): Unit = {
    refreshMonitorTextIfDevelopment()
    openFile("TraceMonitor.scala")
    writeln(ResourceReader.read("Monitor.txt"))
    writeln()
    for (property <- properties) {
      val name = property.name
      val variables = property.ltl.getVariables
      writeln(
        s"""
           |/*
           |  property $name: ${property.ltl}
           |*/
           |
           |class Formula_$name(monitor: Monitor) extends Formula(monitor) {
          """
          .stripMargin)

      val lhs = variables.map { case (n, b) => s"var_$n" }.mkString(" :: ") + " :: Nil"
      val rhs = variables.map { case (n, b) => (quote(n), b) }.mkString(", ")
      writeln(s"  val $lhs = declareVariables($rhs)")

      writeln()

      writeln("  override def evaluate(): Boolean = {")
      LTL.translate(property.ltl)
      val size = LTL.next
      val subFormulas: String = LTL.subExpressions.map(e => quote(e.toString)).mkString(",\n      ")
      val indices: String = LTL.indicesOfPastTimeFormulas.mkString(",")

      writeln(
        s"""
           |    debugMonitorState()
           |
           |    val error = now(0).isZero
           |    if (error) monitor.recordResult()
           |    tmp = now
           |    now = pre
           |    pre = tmp
           |    touchedByLastEvent = emptyTouchedSet
           |    !error
           |  }
           |
           |  varsInRelations = Set(${LTL.varsInRelations.map(quote).mkString(",")})
           |  val indices: List[Int] = List($indices)
           |
           |  pre = Array.fill($size)(bddGenerator.False)
           |  now = Array.fill($size)(bddGenerator.False)
           |
           |  txt = Array(
           |    $subFormulas
           |  )
           |
           |  debugMonitorState()
           |}
        """.stripMargin)
    }

    writeln()
    val constructors = properties.map(_.name).map(nm => s"new Formula_$nm(this)").mkString(",")
    writeln(
      s"""
         |/* The specialized Monitor for the provided properties. */
         |
        |class PropertyMonitor extends Monitor {
         |  formulae ++= List($constructors)
         |}
      """.stripMargin)

    writeln()
    writeln(
      """
        |object TraceMonitor {
        |  def main(args: Array[String]): Unit = {
        |    if (1 <= args.length && args.length <= 3) {
        |      if (args.length > 1) Options.BITS = args(1).toInt
        |      val m = new PropertyMonitor
        |      val file = args(0)
        |      if (args.length == 3 && args(2) == "debug") Options.DEBUG = true
        |      //try {
        |        openFile("dejavu-results")
        |        m.submitCSVFile(file)
        |        closeFile()
        |      //} catch {
        |      //  case e: Throwable => println(s"\n*** $e\n")
        |      //}
        |    } else {
        |      println("*** call with these arguments:")
        |      println("<logfile> [<bits> [debug]]")
        |    }
        |  }
        |}
      """.stripMargin)
    closeFile()
    if (DEBUG_AST) printDot()
  }

  override def toString: String =
    properties.mkString("\n")

  def printDot() {
    val pw = new PrintWriter(new File("ast.dot"))
    for (p <- properties) {
      pw.write("digraph G {\n")
      pw.write(p.ltl.toDot)
      pw.write("}\n")
    }
    pw.close
  }
}

case class Property(name: String, ltl: LTL) {
  override def toString: String =
    s"$name : $ltl"
}

trait LTL {
  var index: Int = 0

  /**
    * Create an assignment statement to <code>now(index)</code>.
    *
    * @param index the index of <code>now</code> to assign to.
    * @param rhs   the right-hand side of the assignment statement.
    * @return the assignment statement as a string.
    */

  def mkAssignment(index: Int, rhs: String): String = s"      now($index) = $rhs"

  /**
    * Assign first.
    *
    * @param index the index of <code>now</code> to assign to.
    * @param rhs   the right-hand side of the assignment statement.
    */

  def assignFirst(index: Int)(rhs: String): Unit = {
    LTL.assignments1 :+= mkAssignment(index, rhs)
  }

  /**
    * Assign there after.
    *
    * @param index the index of <code>now</code> to assign to.
    * @param rhs   the right-hand side of the assignment statement.
    */

  def assign(index: Int)(rhs: String): Unit = {
    LTL.assignments2 :+= mkAssignment(index, rhs)
  }

  /**
    * Get all quantified variables (and whether they are bounded or not - true = yes)
    * in LTL term. That is, all variables defined under and existential or universal
    * quantification. Note that this is not the list of free variables in the LTL formula.
    *
    * @return the list of quantified variables and their boundedness status in the LTL term.
    */

  def getVariables: List[(String, Boolean)] = Nil

  def translate(): Int = {
    index = LTL.getIndex()
    LTL.subExpressions ++= List(this)
    index
  }

  def toDot = s"  $index [shape=box, label=${quote(index + " : " + toString)}]\n"
}

object LTL {
  /**
    * Counter used to keep track of sub-formula indexes.
    */

  var next: Int = 0

  /**
    * Will after translation of the current LTL property contain all its sub-formulas
    * in positions corresponding to their indexes. This is used to annotate debugging
    * output with which formulas correspond to which indexes.
    */

  var subExpressions: List[LTL] = Nil

  /**
    * Will after translation of the current LTL property contain the indexes of past time
    * formulas, such as S (since), @ (previous), P (sometime), etc. This is used by the
    * garbage collection algorithm.
    */

  var indicesOfPastTimeFormulas: List[Int] = Nil

  /**
    * Compute the index for the next sub-formula.
    *
    * @return the next index.
    */

  def getIndex(): Int = {
    val index = next
    next += 1
    index
  }

  /**
    * Lists storing assignment statements generated during translation to the
    * <code>now</code> array. <code>assignments1</code> will be printed out first (corresponds to
    * events in leaf nodes) and <code>assignments2</code> will be printed out thereafter.
    * Leaf node events must be printed first to provide variable bindings for evaluating
    * relations.
    */

  var assignments1: List[String] = Nil
  var assignments2: List[String] = Nil

  /**
    * Any variables used in a relation will be added to this set.
    */

  var varsInRelations: Set[String] = Set()

  /**
    * Resets this LTL object for translating a new property.
    */

  def reset(): Unit = {
    next = 0
    subExpressions = Nil
    indicesOfPastTimeFormulas = Nil
    assignments1 = Nil
    assignments2 = Nil
    varsInRelations = Set()
  }

  /**
    * Translates an LTL formula.
    *
    * @param ltl the formula to be translated.
    */

  def translate(ltl: LTL): Unit = {
    reset()
    ltl.translate()
    (assignments1 ++ assignments2) foreach writeln
  }
}

case object True extends LTL {
  override def translate(): Int = {
    super.translate()
    assign(index)("True")
    index
  }

  override def toString: String = "true"
}

case object False extends LTL {
  override def translate(): Int = {
    super.translate()
    assign(index)(s"False")
    index
  }

  override def toString: String = "false"
}

case class Pred(name: String, values: List[ConstOrVar]) extends LTL {
  override def translate(): Int = {
    super.translate()
    val predName = quote(name)
    val patterns = values.map(_.toStringForSynthesis).mkString(",")
    assignFirst(index)(s"build($predName)($patterns)")
    index
  }

  override def toString: String = {
    val patterns =
      if (values.isEmpty) "" else "(" + values.map(_.toString).mkString(",") + ")"
    s"$name$patterns"
  }
}

trait RelOp {
  def getName: String = this.getClass.getSimpleName.dropRight(1)
}

case object LTOP extends RelOp {
  override def toString: String = "<"
}

case object LEOP extends RelOp {
  override def toString: String = "<="
}

case object GTOP extends RelOp {
  override def toString: String = ">"
}

case object GEOP extends RelOp {
  override def toString: String = ">="
}

case object EQOP extends RelOp {
  override def toString: String = "="
}

case class Rel(varName1: String, op: RelOp, varName2: String) extends LTL {
  override def translate(): Int = {
    super.translate()
    val varName1Q = quote(varName1)
    val varName2Q = quote(varName2)
    assign(index)(s"relation($varName1Q,${op.getName},$varName2Q).or(pre($index))")
    LTL.varsInRelations ++= Set(varName1, varName2)
    index
  }

  override def toString: String = s"$varName1 $op $varName2"
}

case class RelConst(varName: String, op: RelOp, const: Any) extends LTL {
  override def translate(): Int = {
    super.translate()
    val varNameQ = quote(varName)
    val constQ = quote(const)
    assign(index)(s"relationToConstant($varNameQ,${op.getName},$constQ).or(pre($index))")
    LTL.varsInRelations ++= Set(varName)
    index
  }

  override def toString: String = s"$varName $op $const"
}

case class Paren(ltl: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = ltl.getVariables

  override def translate(): Int = {
    index = ltl.translate()
    index
  }

  override def toString: String = s"($ltl)"

  override def toDot: String = ltl.toDot
}

case class Not(ltl: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"now($index1).not()")
    index
  }

  override def toString: String = s"!$ltl"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class Or(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index1).or(now($index2))")
    index
  }

  override def toString: String = s"${bracket(ltl1)} | ${bracket(ltl2)}"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class And(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index1).and(now($index2))")
    index
  }

  override def toString: String = s"${bracket(ltl1)} & ${bracket(ltl2)}"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class Implies(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index1).not().or(now($index2))")
    index
  }

  override def toString: String = s"${bracket(ltl1)} -> ${bracket(ltl2)}"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class Since(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] =
    ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index2).or(now($index1).and(pre($index)))")
    LTL.indicesOfPastTimeFormulas ::= index
    index
  }

  override def toString: String = s"${bracket(ltl1)} S ${bracket(ltl2)}"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class Previous(ltl: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"pre($index1)")
    LTL.indicesOfPastTimeFormulas ::= index
    index
  }

  override def toString: String = s"@ $ltl"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class Sometime(ltl: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"now($index1).or(pre($index))")
    LTL.indicesOfPastTimeFormulas ::= index
    index
  }

  override def toString: String = s"P $ltl"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class History(ltl: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = ltl.getVariables

  val rewrite: LTL = Not(Sometime(Not(ltl)))

  override def translate(): Int = {
    rewrite.translate()
    index = rewrite.index // check that this works
    index
  }

  override def toString: String = s"H $ltl"

  override def toDot: String = {
    rewrite.toDot
  }
}

case class Interval(ltl1: LTL, ltl2: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] =
    ltl1.getVariables ++ ltl2.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl1.translate()
    val index2 = ltl2.translate()
    assign(index)(s"now($index1).or(now($index2).not().and(pre($index)))")
    LTL.indicesOfPastTimeFormulas ::= index
    index
  }

  override def toString: String = s"[$ltl1,$ltl2)"

  override def toDot: String = {
    super.toDot +
      ltl1.toDot +
      ltl2.toDot +
      s"  $index -> ${ltl1.index}\n" +
      s"  $index -> ${ltl2.index}\n"
  }
}

case class Exists(name: String, ltl: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = List((name, false)) ++ ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"now($index1).exist(var_$name.quantvar)")
    index
  }

  override def toString: String = s"Exists $name . ${bracket(ltl)}"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class Forall(name: String, ltl: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = List((name, false)) ++ ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"now($index1).forAll(var_$name.quantvar)")
    index
  }

  override def toString: String = s"Forall $name . ${bracket(ltl)}"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class ExistsSeen(name: String, ltl: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = List((name, true)) ++ ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"var_$name.seen.and(now($index1)).exist(var_$name.quantvar)")
    index
  }

  override def toString: String = s"exists $name . ${bracket(ltl)}"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

case class ForallSeen(name: String, ltl: LTL) extends LTL {
  override def getVariables: List[(String, Boolean)] = List((name, true)) ++ ltl.getVariables

  override def translate(): Int = {
    super.translate()
    val index1 = ltl.translate()
    assign(index)(s"var_$name.seen.imp(now($index1)).forAll(var_$name.quantvar)")
    index
  }

  override def toString: String = s"forall $name . ${bracket(ltl)}"

  override def toDot: String = {
    super.toDot +
      ltl.toDot +
      s"  $index -> ${ltl.index}\n"
  }
}

trait ConstOrVar {
  def toStringForSynthesis: String
}

case class CPat(value: Any) extends ConstOrVar {
  def toStringForSynthesis: String = {
    //val v = if (value.isInstanceOf[String]) quote(value) else value.toString
    s"C($value)"
  }

  override def toString: String = value.toString
}

case class VPat(variable: String) extends ConstOrVar {
  def toStringForSynthesis: String = {
    s"V(${quote(variable)})"
  }

  override def toString: String = variable
}