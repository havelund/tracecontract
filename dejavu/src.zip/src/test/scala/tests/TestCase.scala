package tests

import scala.io.Source
import dejavu.Settings

class TestCase {
  val PATH_TO_TESTS = Settings.PROJECT_DIR + "/src/test/scala/tests"

  def readResult(): List[String] = {
    Source.fromFile("dejavu-results").getLines.toList
  }

  def checkViolations(lines: Any*): Unit = {
    val expect = lines.toList.map(_.toString)
    val result = readResult()
    assert(expect == result,
      s"""
         |expected : (${expect.mkString(",")})
         |=/=
         |observed : (${result.mkString(",")})
       """.stripMargin)
  }

  implicit def liftInt(line: Int) = new {
    def --(value: Any) : String = {
      s"$line -- $value"
    }
  }
}

// class TestCase {
//   val PATH_TO_TESTS = Settings.PROJECT_DIR + "/src/test/scala/tests"
//
//   def readResult(): List[Int] = {
//     Source.fromFile("dejavu-results").getLines.toList.map(_.toInt)
//   }
//
//   def checkViolations(lines : Int*): Unit = {
//     val expect = lines.toList
//     val result = readResult()
//     assert(expect == result,
//       s"""
//          |expected : (${expect.mkString(",")})
//          |=/=
//          |observed : (${result.mkString(",")})
//        """.stripMargin)
//   }
// }