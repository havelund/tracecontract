package tests.util.tracegenerator

import java.io._

abstract class Generator(fileName: String) {
  var counter: Int = 0
  type Evr = (Int, String, List[Any])
  val pwQTL = new PrintWriter(new File(fileName))

  def repeat(nr: Int)(code: => Unit): Unit = {
    for (i <- 1 to nr) {
      code
    }
  }

  def iterate(limit1: Int, limit2: Int, step: Int = 1)(event: String, arguments: Any*): Unit = {
    println(s"---from $limit1 to $limit2 step $step : $event(${arguments.mkString(",")}) ------------------------")
    val args = arguments.toList
    for (i <- limit1 to limit2 by step) {
      counter +=1
      val evr: Evr = (counter, event, i :: args)
      emitEvr(evr)
    }
  }

  def emitEvr(evr: Evr): Unit = {
    val formattedQTL = formatQTL(evr)
    println(formattedQTL)
    pwQTL.write(formattedQTL + "\n")
  }

  def emit(event: String, args: Any*): Unit = {
    counter += 1
    val evr = (counter, event, args.toList)
     emitEvr(evr)
  }

  def formatQTL(event: Evr): String = {
    val (counter, name, args) = event
    s"$name,${args.mkString(",")}"
  }

  def formatMonPoly(event: Evr): String = {
    val (counter, name, args) = event
    f"@$counter%07d $name (${args.mkString(",")})"
  }

  //  @000001 open (aaa)
  //  @000002 open (aah)

  def up(limit1: Int, limit2: Int)(event: String, arguments: Any*): Unit = {
    iterate(limit1, limit2)(event: String, arguments: _*)
  }

  def down(limit1: Int, limit2: Int)(event: String, arguments: Any*): Unit = {
    iterate(limit1, limit2, -1)(event: String, arguments: _*)
  }

  def end(): Unit = {
    println(s"$counter events generated")
    pwQTL.close()
  }

  def run()
}



