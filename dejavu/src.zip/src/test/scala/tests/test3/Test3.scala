package tests.test3

import dejavu.Verify
import org.junit.Test
import tests.TestCase

class Test3 extends TestCase {
  val TEST = PATH_TO_TESTS + "/test3"
  val spec = s"$TEST/spec.qtl"
  val log1 = s"$TEST/log1.csv"

  @Test def test1(): Unit = {
    Verify(spec,log1)
    checkViolations(6,14,16,17,21)
  }
}

