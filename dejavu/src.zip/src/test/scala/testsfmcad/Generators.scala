package testsfmcad

object Util {
  val dir = "/Users/khavelun/Desktop/"
}
import Util._
import tests.util.tracegenerator.Generator

class Generator1 extends Generator(dir + "log.csv") {
  /*

    prop secure :
      forall user . forall file .
         access(user,file) ->
           [login(user),logout(user))
             &
            [open(file),close(file))
   */

  val login = "login"
  val logout = "logout"
  val open = "open"
  val close = "close"
  val access = "access"

  def run(): Unit = {
    // val MAX = 5000; val MID = 4800 // 11,006 events generated
    // val MAX = 50000; val MID = 48000 // 110,006 events generated
    val MAX = 500000; val MID = 480000 // 1,100,006 events generated

    up(1, MAX)(login)
    up(1, MAX)(open)
    repeat(1) {
      down(MAX,MID)(access,1)
      down(MAX, MID)(close)
      up(MID, MAX)(open)
    }
    down(MAX, MID)(logout)
    down(MAX, MID)(close)
    emit(access,MAX,1)
    end()
  }
}

class Generator2 extends Generator(dir + "log.csv") {
  /*
    prop p : forall f . close(f) -> exists m . @ [open(f,m),close(f))
   */

  val open = "open"
  val close = "close"
  val read = "read"
  val write = "write"

  def run(): Unit = {
    // val MAX = 8000; val MID = 7000 // 11,004 events generated
    // val MAX = 80000; val MID = 70000 // 110,004 events generated
    val MAX = 800000; val MID = 700000 // 1,100,004 events generated

    up(1, MAX)(open,read)
    repeat(1) {
      down(MAX,MID)(close)
      up(MID, MAX)(open,write)
    }
    down(MAX, MID)(close)
    emit(close,MAX)
    end()
  }
}

class Generator3 extends Generator(dir + "log.csv") {
  /*
     prop p1 : forall x . enter(x) -> ! @ P enter(x)
     prop p2 : forall x . exit(x) -> ! @ P exit(x)
     prop p3 : forall x . exit(x) -> @ P enter(x)
     prop p4 : forall x . forall y . (P (enter(y) & @ P enter(x))) & exit(y) -> @ P exit(x)
   */

  val enter = "enter"
  val exit = "exit"

  def run(): Unit = {
    // val MAX = 5000; val MID = 50 // 5,050 events generated
    // val MAX = 10000; val MID = 100 // 10,100 events generated
    // val MAX = 100000; val MID = 1000 // 101,000 events generated
    val MAX = 1000000; val MID = 10000 // 1,010,000 events generated
    up(1, MAX)(enter)
    up(1, MID)(exit)
    emit(exit,MAX)
    end()
  }
}

object Main {
  def main(args: Array[String]): Unit = {
    val generator = new Generator3
    generator.run()
  }
}
